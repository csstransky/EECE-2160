#ifndef WIIMOTE_H
#define WIIMOTE_H
#include <iostream>
class Wiimote 
{
	int fd;

public:

	Wiimote();

	~Wiimote();

	void ButtonEvent(int code, int value);

	void Listen();
};

#endif
