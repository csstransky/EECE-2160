#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <sys/mman.h>
#include <cstdio>
#include <math.h>

class ZedBoard
{
	char *ptr;
	int fd;
public:
	ZedBoard();
	
	~ZedBoard();
	
	void RegisterWrite(int offset, int value);

	int RegisterRead(int offset);

	void setLed(int led, int value);
};
