#include "Wiimote.h"
#include "ZedBoard.h"
#include <iostream>

// Child to the Wiimote parent class
class WiimoteToLed : public Wiimote
{
	ZedBoard * zed;
public:

	// Class constructor for WiimoteToLed
	WiimoteToLed(ZedBoard * zed)
		:Wiimote()
	{
		this->zed = zed;
	}
	
	// Turns on LEDs before index, and turns off LEDs after index
	void matchLeds(int index)
	{
		for(int i = 0; i < index; i++) 
		{
			zed->setLed(i, 1);
		}
		for(int j = index; j < 8; j++)
		{
			zed->setLed(j, 0);
		}
	}
	
	// Overrides the function of Wiimote to set LEDs on ZedBoard
	void AccelerationEvent(int code, int acceleration)
	{
		if (acceleration < 0)
		{
			acceleration = acceleration * -1;
		}

		if(code != 3)
		{
			return;
		}
		
		std::cout << "Raw Acceleration " << acceleration << "\n";
		
		if(acceleration > 100 || acceleration < -100)
		{
			matchLeds(7);
		} 
		else 
		{
			acceleration = acceleration / 13;

			std::cout << "Acceleration " << acceleration << "\n";
			matchLeds(acceleration);
		}
	}
};

int main()
{
	// Instantiate ZedBoard object statically
	ZedBoard zed_board;

	// Instantiate WiimoteToLed object statically, passing a pointer to the
	// recently created ZedBoard object.
	WiimoteToLed wiimote_to_led(&zed_board);
	
	// Enter infinite loop listening to events. The overridden function
	// WiimoteToLed::AccelerationEvent() will be invoked when the user moves
	// the Wiimote.
	wiimote_to_led.Listen();

	// Unreachable code, previous function has an infinite loop
	return 0;
}
