#include "ZedBoard.h"
#include <iostream>

// Physical base address of GPIO
const unsigned gpio_address = 0x400d0000;

// Length of memory-mapped IO window
const unsigned gpio_size = 0xff;
const int gpio_led1_offset = 0x12C; // Offset for LED1
const int gpio_led2_offset = 0x130; // Offset for LED2
const int gpio_led3_offset = 0x134; // Offset for LED3
const int gpio_led4_offset = 0x138; // Offset for LED4
const int gpio_led5_offset = 0x13C; // Offset for LED5
const int gpio_led6_offset = 0x140; // Offset for LED6
const int gpio_led7_offset = 0x144; // Offset for LED7
const int gpio_led8_offset = 0x148; // Offset for LED8

int state = 0;
int counter = 0;

/**
* Initialize general-purpose I/O
* - Opens access to physical memory /dev/mem
* - Maps memory at offset 'gpio_address' into virtual address space
*
* @param fd
* File descriptor passed by reference, where the result
* of function 'open' will be stored.
*
*/
ZedBoard::ZedBoard()
{
	fd = open( "/dev/mem", O_RDWR);
	ptr = (char *) mmap(
		NULL,
		gpio_size,
		PROT_READ | PROT_WRITE,
		MAP_SHARED,
		fd,
		gpio_address);	
	// Check error
	if (ptr == MAP_FAILED)
	{	
		perror("Mapping I/O memory failed - Did you run with 'sudo'?\n");
	}
}

/**
 * Close general-purpose I/O.
*
* @param ptr Virtual address where I/O was mapped.
* @param fd File descriptor previously returned by 'open'.
*/
ZedBoard::~ZedBoard()
{
	munmap(ptr, gpio_size);
	close(fd); 
}

/**
 * Write a 4-byte value at the specified general-purpose I/O location.
 *
 * @param ptr Base address returned by 'mmap'.
 * @parem offset Offset where device is mapped.
 * @param value Value to be written.
*/
void ZedBoard::RegisterWrite(int offset, int value)
{
	* (int *) (ptr + offset) = value;
}	
 
/** 
 * Read a 4-byte value from the specified general-purpose I/O location.
 *
 * @param ptr Base address returned by 'mmap'.
 * @param offset Offset where device is mapped.
 * @return Value read.
 */
int ZedBoard::RegisterRead(int offset)
{
	return * (int *) (ptr + offset);
}

/** Set the state of the LED with the given index.
 *
 * @parem led LED index between 0 and 7
 * @param value Turn on (1) or off (0)
 */
void ZedBoard::setLed(int led, int value)
{
	 switch(led) {
  		 case 7:	
			RegisterWrite(gpio_led1_offset, value);
			break;
		 case 6:	
			RegisterWrite(gpio_led2_offset, value);
			break;
  		 case 5:	
			RegisterWrite(gpio_led3_offset, value);
			break;
  		 case 4:	
			RegisterWrite(gpio_led4_offset, value);
			break;
  		 case 3:	
			RegisterWrite(gpio_led5_offset, value);
			break;
  		 case 2:	
			RegisterWrite(gpio_led6_offset, value);
			break;
  		 case 1:	
			RegisterWrite(gpio_led7_offset, value);
			break;
  		 case 0:	
			RegisterWrite(gpio_led8_offset, value);
  			break; 
		default:	
			std::cout << "Invalid index.";
	}
}

