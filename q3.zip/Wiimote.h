#ifndef WIIMOTE_H
#define WIIMOTE_H

#include <iostream>

class Wiimote 
{
	int fd;

public:

	Wiimote();

	~Wiimote();

	virtual void ButtonEvent(int code, int value);

	virtual void AccelerationEvent(int code, int acceleration);	

	void Listen();
};

#endif
