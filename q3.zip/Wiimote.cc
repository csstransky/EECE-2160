#include "Wiimote.h"
#include <iostream>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h> 

// Constructs the Wiimote class, needs sudo to work
Wiimote::Wiimote()
{
        // Open Wiimote event file
	fd = open("/dev/input/event0", O_RDONLY);
	if (fd == -1)
 	{
		std::cerr << "Error: Could not open event file - forgot sudo?\n";
		exit(1);
	} 	
}

// Deconstructor for the Wiimote
Wiimote::~Wiimote()
{
	close(fd);
	std::cout << "Hi, I'm closing.";
}

// Displays the place in memory for a button pressed, and its value
void Wiimote::ButtonEvent(int code, int value)
{
		std::cout << "Code: " << code << ", Value: " << value << "\n";
}

// Displays which axis is being moved (code) and its acceleration value
void Wiimote::AccelerationEvent(int code, int acceleration)
{
		std::cout << "Code: " << code 
		<< ", Acceleration: " << acceleration  << "\n";
}

// Listens indefinitely to get acceleration value
void Wiimote::Listen()
{
	while(true)
	{
		// Read a packet of 32 bytes from Wiimote
		char buffer[32];
		read(fd, buffer, 32);
		// Extract code (byte 10) and value (byte 12) from packet
		int code = buffer[10];
		int value = buffer[12]; 
			
		AccelerationEvent(code, value);
	}
}
