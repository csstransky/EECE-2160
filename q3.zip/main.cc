#include "Wiimote.h"

int main()
{
	// Initialize
	Wiimote wii;
	wii.Listen();
	return 0;
}
